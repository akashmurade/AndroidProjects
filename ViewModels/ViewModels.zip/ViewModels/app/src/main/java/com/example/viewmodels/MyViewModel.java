package com.example.viewmodels;

import android.view.View;

import androidx.lifecycle.ViewModel;

public class MyViewModel extends ViewModel {
    int counter;

    public MyViewModel() {
        counter = 0;
    }

    public MyViewModel(int counter) {
        this.counter = counter;
    }

    public void onIncrease(View view) {
        counter++;
    }

    public int getCounter() {
        return counter;
    }

    public void onDecrease(View view) {
        counter--;
    }
}
